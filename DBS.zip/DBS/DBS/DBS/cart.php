<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $_POST['user_id'];
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $product_details = $_POST['product_details'];
    $product_name = $_POST['product_name'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'db_project');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind statement
    $stmt = $conn->prepare("INSERT INTO Cart (user_ID, product_ID, cart_ID, Quantity, productDetails, productName) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisss", $user_id, $product_id, $cart_id, $quantity, $product_details, $product_name);

    // Execute statement
    if ($stmt->execute()) {
        echo "Item added to cart successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Cart</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: palevioletred;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: palevioletred;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px; /* Adjust the width as needed */
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

    </style>
</head>
<body>


    <form action="" method="post">
        <h2>Add to Cart</h2>
        <label for="user_id">User ID:</label>
        <input type="text" id="user_id" name="user_id" required>

        <label for="product_id">Product ID:</label>
        <input type="text" id="product_id" name="product_id" required>

        <input type="hidden" id="idInput" name="id">

        <label for="quantity">Quantity:</label>
        <input type="text" id="quantity" name="quantity" required>

        <label for="product_details">Product Details:</label>
        <input type="text" id="product_details" name="product_details" required>

        <label for="product_name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" required>

        <button type="submit">Add to Cart</button>
    </form>

</body>
</html>
