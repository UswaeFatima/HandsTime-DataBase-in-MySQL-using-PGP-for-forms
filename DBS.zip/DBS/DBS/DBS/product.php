
<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $product_name = $_POST['product_name'];
        $price = $_POST['price'];
        $description = $_POST['description'];
        $image_url = $_POST['image_url'];
        $category_id = $_POST['category_id'];

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'db_project');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind statement
        $stmt = $conn->prepare("INSERT INTO Product (product_Name, price, description, imageURL, category_ID) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sdssi", $product_name, $price, $description, $image_url, $category_id);

        // Execute statement
        if ($stmt->execute()) {
            echo "Product registration successful!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Registration</title>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: palevioletred;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: palevioletred;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px; /* Adjust the width as needed */
}

input,
textarea {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

</style>
</head>
<body>


    <form action="" method="post">
        <h2>Product Registration</h2>
        
        <input type="hidden" id="idInput" name="id">

        <label for="product_name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" required>

        <label for="price">Price:</label>
        <input type="number" step="0.01" id="price" name="price" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4" required></textarea>

        <label for="image_url">Image URL:</label>
        <input type="text" id="image_url" name="image_url" required>

        <label for="category_id">Category ID:</label>
        <input type="text" id="category_id" name="category_id" required>

        <button type="submit">Register Product</button>
    </form>

</body>
</html>
