<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $product_id = $_POST['product_id'];
        $user_id = $_POST['user_id'];
        $order_status = $_POST['order_status'];
        $order_date = $_POST['order_date'];
        $shipping_method = $_POST['shipping_method'];
        $shipping_address = $_POST['shipping_address'];

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'db_project');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind statement
        $stmt = $conn->prepare("INSERT INTO Orders (order_ID, product_ID, user_ID, order_status, order_date, shipping_method, shippingAddress) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiissss", $order_id, $product_id, $user_id, $order_status, $order_date, $shipping_method, $shipping_address);

        // Execute statement
        if ($stmt->execute()) {
            echo "Order placed successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Order</title>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px; /* Adjust the width as needed */
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

</style>
</head>
<body>
    <form action="#" method="post">
        <h2>Place Order</h2>
        
        <input type="hidden" id="idInput" name="id">


        <label for="product_id">Product ID:</label>
        <input type="text" id="product_id" name="product_id" required>

        <label for="user_id">User ID:</label>
        <input type="text" id="user_id" name="user_id" required>

        <label for="order_status">Order Status:</label>
        <input type="text" id="order_status" name="order_status" required>

        <label for="order_date">Order Date:</label>
        <input type="text" id="order_date" name="order_date" required>

        <label for="shipping_method">Shipping Method:</label>
        <input type="text" id="shipping_method" name="shipping_method" required>

        <label for="shipping_address">Shipping Address:</label>
        <input type="text" id="shipping_address" name="shipping_address" required>

        <button type="submit">Place Order</button>
    </form>

</body>
</html>
