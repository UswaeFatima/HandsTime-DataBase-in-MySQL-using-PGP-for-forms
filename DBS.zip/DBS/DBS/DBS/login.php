<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone_number = $_POST['phone_number'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'db_project');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind statement
    $stmt = $conn->prepare("INSERT INTO User (user_Name, Email, password, phone_number) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $user_name, $email, $password, $phone_number);

    // Execute statement
    // if ($stmt->execute()) {
    //     echo "User registration successful!";
    // } else {
    //     echo "Error: " . $stmt->error;
    // }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
 <style>
  body {
    font-family: Arial, sans-serif;
    background-color:palevioletred;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color:palevioletred;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 200px; 
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

 </style>
</head>
<body>

    <form action="" method="post">
        <h2>User Registration</h2>
        <input type="hidden" id="idInput" name="id">

        <label for="user_name">Username:</label>
        <input type="text" id="user_name" name="user_name" required>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number" required>

        <button type="submit">Register</button>
    </form>

</body>
</html>
