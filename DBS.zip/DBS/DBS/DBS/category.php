<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $category_name = $_POST['category_name'];

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'db_project');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind statement
        $stmt = $conn->prepare("INSERT INTO Category (categoryName) VALUES (?)");
        $stmt->bind_param("s", $category_name);

        // Execute statement
        // if ($stmt->execute()) {
        //     echo "Category registration successful!";
        // } else {
        //     echo "Error: " . $stmt->error;
        // }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Registration</title>
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: palevioletred;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: palevioletred;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 200px; 
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

    </style>
</head>
<body>

    <form action="#" method="post">
        <h2>Category Registration</h2>
        <label for="category_name">Category Name:</label>
        <input type="text" id="category_name" name="category_name" required>

        <button type="submit">Add Category</button>
    </form>

</body>
</html>
